
//
// occurrences.h
//
// Copyright (c) 2013 Stephen Mathieson
// MIT licensed
//


#ifndef OCCURRENCES_H
#define OCCURRENCES_H 1

size_t
occurrences(const char *, const char *);

#endif

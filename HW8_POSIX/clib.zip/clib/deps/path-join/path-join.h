
//
// path-join.h
//
// Copyright (c) 2013 Stephen Mathieson
// MIT licensed
//


#ifndef PATH_JOIN_H
#define PATH_JOIN_H 1

char *
path_join(const char *, const char *);

#endif

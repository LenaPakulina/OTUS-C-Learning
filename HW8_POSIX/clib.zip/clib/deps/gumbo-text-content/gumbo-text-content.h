
#ifndef GUMBO_TEXT_CONTENT_H
#define GUMBO_TEXT_CONTENT_H 1

#include "gumbo-parser/gumbo.h"

char *
gumbo_text_content(GumboNode *);

#endif

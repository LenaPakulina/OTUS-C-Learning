#ifndef STR_CAT_H
#define STR_CAT_H 1

char *concat(const char *s1, const char *s2);

#endif
